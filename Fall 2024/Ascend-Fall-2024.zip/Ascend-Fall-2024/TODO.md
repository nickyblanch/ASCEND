DONT CLOCK THE WIRE TOO HIGH!!!!!!!!

[BOM Reference](https://docs.google.com/spreadsheets/d/1N5uVJxHqoAoPkoaKqldwrL5gkkNrfWoROLorwC07GB8/edit?gid=0#gid=0)

[X] Implement SD card reader

[ ] Test SD card reader

[IMU - Working!](https://www.amazon.com/SparkFun-Breakout-ICM-20948-connection-Accelerometer-Magnetometer/dp/B07VNV3WKL/ref=sr_1_5?dib=eyJ2IjoiMSJ9.zut0si1EgNuAunnwh53jR9K3fwmtDBGnjPsK0BBhua8VzM9GI-MZUrkxfKsigUYw361zJVofu_bu6eKNT8IQlXLpH7pidhXetTAIFJlaxrRegZzDBgCClXPgyPzYL0XRVGnBwrs8Le2ZqcQzff0QqJkt9p2Q-vp4-TS9zkRGBowtwXIyu0nr2pUgmE4J6NsUlEbnRrsc_PN3kU133GZcPRuXRsjfZMazkh7UQV3eqts.Zji-k2GXt0GpUzTaUluWIVIL15KOn-H4fRlYMxn8q4M&dib_tag=se&keywords=imu&qid=1726267521&sr=8-5)

[BME 680 - Test](https://www.amazon.com/CJMCU-680-Temperature-Humidity-Ultra-Small-Development/dp/B07K1CGQTJ/ref=sr_1_2_sspa?crid=NA1H9LQK1ZOE&dib=eyJ2IjoiMSJ9.jGZYtCsiOdCENY2-xmMxBtf3OFaa0lWf_2LUUsJix1TUxphYSUXrqVGf81DM_8ecy5WlmsjPk4GbQQwOJF8boDbNJIcLu-IVRY2b61Hna1wNUWc17MmcneOkCvQojSgeT7SMPWe4mNSc5A4Giofezgy2_GCKKm4wIAr9IbtEPU03QiTsgkxlN4Ql8BA5loT6PBV55_XJgq_uHSVf7918IG2y-BOUisHgJwYUsK1akVQ.wbf7Pv73oxp4xiSwSxKle3G8TFnGm3f_Jpq7xVw1iYY&dib_tag=se&keywords=bme680+sensor&qid=1726267810&sprefix=bme680+sensor%2Caps%2C136&sr=8-2-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1)

[UV Sensor - Working!](https://www.amazon.com/SparkFun-Mini-Spectral-Sensor-Built/dp/B0CQF6JD41/ref=sr_1_1?crid=2KQVB2JZCAPY0&dib=eyJ2IjoiMSJ9.26hFoTymPAX66mnthuL6rX0XP4U1Rioi3bdsPl_R91knOC-E0PNJEsCz3TniwlsqqWyPRhY7vXEBpUK8JL3_0uV8shcZEQBT71HAi956aEM.VBUdQXG2L2Hq411J9f6Re3EDJy0Czszy2Lw0IadW350&dib_tag=se&keywords=as7331&qid=1726269356&sprefix=as7331%2Caps%2C107&sr=8-1#customerReviews)

[Spectral Sensor - Working!](https://www.sparkfun.com/sparkfun-spectral-sensor-breakout-as7262-visible-qwiic.html)

[Temperature - Working!](https://www.amazon.com/HiLetgo-Precision-Temperature-Humidity-2-0-5-5V/dp/B09KGW1G41/ref=sr_1_7_sspa?crid=2CDHFAX7ZFL7H&dib=eyJ2IjoiMSJ9.oxx3ExU4s55DQvUzbRBPF95FUP2HvuOiIiyViyyETthJ4Zf0Rnb1SqJk-G63X6lzUXKT66xmiZC0jvu-F9A7HhHx7j9jVml9qOHGan9sVE63ohpRmUmV-2Jzce81TDL7OaASd6UgjtSUFhCAygzIXKT18esXFoet7jLOchn9vP-jbBRg4kkwPHn7UeovpqDdr0L1RL4hg-8PEKp1wjMl-R5naWN-xhQ3p6iYPhWvzCE.1YjmQltsjD_TT1zvHyeQLtAoiAr8sSIGFHcMh9rzPvQ&dib_tag=se&keywords=temperature+sensor+arduino&qid=1726269945&sprefix=temperature+sensor+arduino%2Caps%2C138&sr=8-7-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9tdGY&psc=1)

[IR Sensor - Working!](https://www.amazon.com/SparkFun-Spectral-Sensor-Breakout-Communicates/dp/B07944C1J2?crid=395S0E5CFSZSB&dib=eyJ2IjoiMSJ9.Y0ETy9YsRgjpb0vD78azB5tdcVHNqeKCtpOdGJ6tyI6_dTfe3B5FLPnmjJf14S_mGIsL1r648QnFtUtpEPRm3sOXJ5I54r1uefV0PHSaDjRan3Cn-0udqSMHjN6SaSIvz2DFH4xLZKTeXVA8aUqlnQ.kMHMyz6MJ5TtMgaWhpYtL495QoAJZHI0RsMNSgApGao&dib_tag=se&keywords=sparkfun+spectral+sensor+breakout+nir&qid=1738361660&sprefix=sparkfun+spectral+sensor+breakout+nir%2Caps%2C175&sr=8-1)

[Air Quality - Broken :/](https://www.amazon.com/waveshare-Compounds-Integration-Treatment-Raspberry/dp/B09FKFYMPR/ref=sr_1_8?crid=YWX3YTNNQFQF&dib=eyJ2IjoiMSJ9.3OlEeHQa7SBoaBuwUp8erXL7vHd_1ezceififF-9oxMZGDHyYBIGZySjuYHJ5K0nboFD22JRNyAet4-JcetcXTGJAZtHExZ5TACd5-TCEa1SNgoPpsUYFud_FSu4bRs7VTprsjpcqpBUOuX08P2izB20r4NR_JRU2sEI0_ipcUJE4udBAHNw4w0l1sjSGGRr_8-n9iKgZ0A8UNRS-I2FELKyhcqKvrMOvcr2oPb3kRQ.iLS1hG_uonVJcYc2q_Z3zzXS5_JQK8kFfm1a7C7xEpk&dib_tag=se&keywords=outside%2Bair%2Bquality%2Bsensor%2Barduino%2Bi2c&qid=1738362671&sprefix=outside%2Bair%2Bquality%2Bsensor%2Barduino%2Bi2c%2Caps%2C135&sr=8-8&th=1)
